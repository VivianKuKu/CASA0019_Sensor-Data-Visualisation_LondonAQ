 typedef void (*CodegenRegistrationFunction) (); CodegenRegistrationFunction g_CodegenRegistration;
