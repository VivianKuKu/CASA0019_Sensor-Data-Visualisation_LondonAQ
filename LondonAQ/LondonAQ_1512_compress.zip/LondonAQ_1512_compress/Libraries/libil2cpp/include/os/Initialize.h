#pragma once


namespace il2cpp
{
namespace os
{
    void Initialize();
    void Uninitialize();
}
}
