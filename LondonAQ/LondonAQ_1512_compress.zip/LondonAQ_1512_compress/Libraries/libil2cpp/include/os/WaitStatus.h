#pragma once

#include "os/c-api/WaitStatus-c-api.h"

namespace il2cpp
{
namespace os
{
    typedef UnityPalWaitStatus WaitStatus;
}
}
