#pragma once

#include <string>

namespace il2cpp
{
namespace os
{
namespace lumin
{
    extern std::string GetPackageName();
    extern std::string GetPackageTempPath();
    extern void LifecycleInit();
}
}
}
