#pragma once

void RegisterFeatures();
